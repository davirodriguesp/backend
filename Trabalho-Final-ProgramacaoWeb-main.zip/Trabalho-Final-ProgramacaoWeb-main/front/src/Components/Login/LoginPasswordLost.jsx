import React from 'react'

const LoginPasswordLost = () => {
  return (
    <div>LoginPasswordLost</div>
  )
}

export default LoginPasswordLost