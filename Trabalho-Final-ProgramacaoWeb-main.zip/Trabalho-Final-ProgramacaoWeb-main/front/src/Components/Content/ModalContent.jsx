import React from 'react';
import styles from './ModalContent.module.css';

const ModalContent = ({data}) => {
    return (
        <div className={styles.content}>
            <div className={styles.img}>
                
            </div>
        </div>
    )
}

export default ModalContent;