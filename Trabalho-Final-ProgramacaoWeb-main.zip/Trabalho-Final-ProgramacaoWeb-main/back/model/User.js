class User{

    constructor(id, usuario, email, senha){

        this.id = id;
        this.usuario = usuario;
        this.email = email;
        this.senha = senha;
    }
}
module.exports = User;