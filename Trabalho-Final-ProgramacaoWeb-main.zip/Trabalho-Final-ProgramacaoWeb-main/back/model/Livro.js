class Livro{

    constructor(id, titulo, autor, editora, pagnum, img){

        this.id = id;
        this.titulo = titulo;
        this.autor = autor;
        this.editora = editora;
        this.pagnum = pagnum;
        this.img = img;
    }
}
module.exports = Livro;